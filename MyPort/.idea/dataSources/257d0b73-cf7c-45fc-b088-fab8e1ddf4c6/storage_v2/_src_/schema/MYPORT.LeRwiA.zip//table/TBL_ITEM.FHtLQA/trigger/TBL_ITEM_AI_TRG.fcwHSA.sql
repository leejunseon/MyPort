create trigger TBL_ITEM_AI_TRG
    before insert
    on TBL_ITEM
    for each row
BEGIN
    SELECT SEQ_ITEM.NEXTVAL
    INTO :NEW.I_NO
    FROM DUAL;
END;
/

