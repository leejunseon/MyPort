create trigger TAB_FIELD_AI_TRG
    before insert
    on TAB_FIELD
    for each row
BEGIN
SELECT TAB_FIELD_SEQ.NEXTVAL
INTO :NEW.F_PK
FROM DUAL;
END;
/

