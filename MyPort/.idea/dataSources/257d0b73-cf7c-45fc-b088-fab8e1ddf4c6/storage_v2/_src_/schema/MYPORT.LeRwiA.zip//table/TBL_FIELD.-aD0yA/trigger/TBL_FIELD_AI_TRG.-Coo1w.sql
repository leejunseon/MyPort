create trigger TBL_FIELD_AI_TRG
    before insert
    on TBL_FIELD
    for each row
BEGIN
    SELECT TBL_FIELD_SEQ.NEXTVAL
    INTO :NEW.F_PK
    FROM DUAL;
END;
/

