create trigger TAB_COUNTRY_AI_TRG
    before insert
    on TAB_COUNTRY
    for each row
BEGIN
SELECT TAB_COUNTRY_SEQ.NEXTVAL
INTO :NEW.C_PK
FROM DUAL;
END;
/

