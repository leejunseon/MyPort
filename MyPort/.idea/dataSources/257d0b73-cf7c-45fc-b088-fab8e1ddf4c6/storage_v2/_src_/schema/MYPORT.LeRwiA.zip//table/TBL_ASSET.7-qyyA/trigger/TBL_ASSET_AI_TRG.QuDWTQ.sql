create trigger TBL_ASSET_AI_TRG
    before insert
    on TBL_ASSET
    for each row
BEGIN
    SELECT SEQ_ASSET.NEXTVAL
    INTO :NEW.A_NO
    FROM DUAL;
END;
/

