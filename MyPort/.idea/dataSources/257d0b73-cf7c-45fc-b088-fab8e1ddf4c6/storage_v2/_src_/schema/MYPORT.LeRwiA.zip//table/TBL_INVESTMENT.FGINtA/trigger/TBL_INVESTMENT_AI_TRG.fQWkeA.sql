create trigger TBL_INVESTMENT_AI_TRG
    before insert
    on TBL_INVESTMENT
    for each row
BEGIN
    SELECT SEQ_INVESTMENT.NEXTVAL
    INTO :NEW.I_NO
    FROM DUAL;
END;
/

