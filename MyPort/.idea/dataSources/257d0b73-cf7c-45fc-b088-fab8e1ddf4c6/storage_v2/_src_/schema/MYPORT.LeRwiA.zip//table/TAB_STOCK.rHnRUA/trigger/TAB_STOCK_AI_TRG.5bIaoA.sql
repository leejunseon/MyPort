create trigger TAB_STOCK_AI_TRG
    before insert
    on TAB_STOCK
    for each row
BEGIN
SELECT TAB_STOCK_SEQ.NEXTVAL
INTO :NEW.S_PK
FROM DUAL;
END;
/

