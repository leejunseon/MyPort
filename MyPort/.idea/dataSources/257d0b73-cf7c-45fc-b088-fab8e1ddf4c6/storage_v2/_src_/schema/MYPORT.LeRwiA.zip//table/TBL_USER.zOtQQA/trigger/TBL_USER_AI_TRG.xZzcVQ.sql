create trigger TBL_USER_AI_TRG
    before insert
    on TBL_USER
    for each row
BEGIN
    SELECT SEQ_USER.NEXTVAL
    INTO :NEW.U_NO
    FROM DUAL;
END;
/

