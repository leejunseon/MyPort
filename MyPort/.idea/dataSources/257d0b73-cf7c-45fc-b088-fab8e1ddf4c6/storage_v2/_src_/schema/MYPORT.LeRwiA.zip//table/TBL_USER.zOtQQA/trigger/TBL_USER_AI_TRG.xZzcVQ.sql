create trigger TBL_USER_AI_TRG
    before insert
    on TBL_USER
    for each row
BEGIN
    SELECT TBL_USER_SEQ.NEXTVAL
    INTO :NEW.U_PK
    FROM DUAL;
END;
/

