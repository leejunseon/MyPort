create trigger TAB_USER_AI_TRG
    before insert
    on TAB_USER
    for each row
BEGIN
SELECT TAB_USER_SEQ.NEXTVAL
INTO :NEW.U_PK
FROM DUAL;
END;
/

