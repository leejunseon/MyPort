create trigger TBL_COUNTRY_AI_TRG
    before insert
    on TBL_COUNTRY
    for each row
BEGIN
    SELECT SEQ_COUNTRY.NEXTVAL
    INTO :NEW.C_NO
    FROM DUAL;
END;
/

