create trigger TBL_COUNTRY_AI_TRG
    before insert
    on TBL_COUNTRY
    for each row
BEGIN
    SELECT TBL_COUNTRY_SEQ.NEXTVAL
    INTO :NEW.C_PK
    FROM DUAL;
END;
/

