create trigger TBL_STOCK_AI_TRG
    before insert
    on TBL_STOCK
    for each row
BEGIN
    SELECT TBL_STOCK_SEQ.NEXTVAL
    INTO :NEW.S_PK
    FROM DUAL;
END;
/

